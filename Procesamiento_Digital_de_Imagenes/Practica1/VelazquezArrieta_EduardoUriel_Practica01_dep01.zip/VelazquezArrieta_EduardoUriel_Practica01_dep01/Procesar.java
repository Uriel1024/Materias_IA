package practica1;
import java.awt.image.BufferedImage;
import java.awt.Color;
public class Procesar {

        public static BufferedImage Procesar(BufferedImage ImagenO, int brillo,float contraste, boolean esgris){


        if (ImagenO == null) return null;

        BufferedImage ImagenP = ImagenO;
        int width = ImagenO.getWidth();
        int height = ImagenO.getHeight();

        ImagenP = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        int r,g,b,rgb, max = 255, min = -256;
        

        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x ++){
                rgb = ImagenO.getRGB(x,y);
                r = (rgb & 0x00FF0000) >> 16;
                g = (rgb & 0x0000FF00) >> 8;
                b = rgb & 0x000000FF;


                int fp;
                if (esgris){
                    fp = (r + g + b )/ 3;
                    fp += brillo;
                    fp = (int) (fp * contraste);
                }else{
                    fp = (int)(g * contraste) + brillo;
                }

                if (fp > max) max = fp;
                if (fp < min) min = fp;
            }
        }

        for(int y = 0; y < height; y++){
            for(int x =0 ; x< width; x++){
                rgb = ImagenO.getRGB(x,y);
                r = (rgb & 0x00FF0000) >> 16;
                g = (rgb & 0x0000FF00) >> 8;
                b = rgb & 0x000000FF;

                if(esgris){
                    int gris = (r + b+ b) / 3;
                    gris += brillo;
                    gris = (int)(gris*contraste);

                    if((max - min) != 0){
                        gris = ((gris - min) * 255) / (max - min);
                    }
                    gris = Math.max(0, Math.min(255, gris));
                    Color color = new Color(gris, gris, gris);
                    ImagenP.setRGB(x, y, color.getRGB());
                }else{
                    r += brillo;  r = (int)(r * contraste);
                    g += brillo;  g = (int)(g * contraste);
                    b += brillo;  b = (int)(b * contraste);

                    if ( (max - min) != 0) {
                        r = ((r - min) * 255) / (max - min);
                        g = ((g - min) * 255) / (max - min);
                        b = ((b - min) * 255) / (max - min);
                    }

                    r = Math.max(0, Math.min(255, r));
                    g = Math.max(0, Math.min(255, g));
                    b = Math.max(0, Math.min(255, b));

                    Color color = new Color(r, g, b);
                    ImagenP.setRGB(x, y, color.getRGB());
                }

            }
        }
        return ImagenP;

    }

    

}