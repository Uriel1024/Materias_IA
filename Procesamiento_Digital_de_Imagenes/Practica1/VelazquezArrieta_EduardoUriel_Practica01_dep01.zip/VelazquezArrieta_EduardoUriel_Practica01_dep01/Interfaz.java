package practica1;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.nio.channels.SelectableChannel;


public class Interfaz extends JFrame {
    private BufferedImage imgOriginal;
    private BufferedImage imgModificada , imgGris;
    private JLabel lblOriginal, lblModificada,lblGris;
    private String eleccion;
    private JSlider br,contr;
    private JLabel lvlbrillo, lvlcontraste; 


    public Interfaz() {
        super("Brillo y contraste");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        // --- Panel de Controles ---
        JPanel pnlContenedor = new JPanel(new   GridLayout(3,1));
        JPanel pnlNorte = new JPanel();
        JPanel pnlBrillo = new JPanel();
        JPanel pnlContraste = new JPanel();


        JButton btnAbrir = new JButton("Abrir Imagen");
        JButton btnProcesar = new JButton("Aplicar Cambios");
        JButton btnGuardar = new JButton("Guardar Resultado");
        br = new JSlider(-256,255,0);
        contr = new JSlider(0,200,0);
        br.setPreferredSize(new Dimension(800,25));
        contr.setPreferredSize(new Dimension(800,25));
        //Labels para mostrar la cantidad seleccionada por el usuario
        lvlbrillo =     new JLabel("Brillo   : " + 0);
        lvlcontraste =  new JLabel("contraste: " + 0.0);
 
        pnlNorte.add(btnAbrir);
        pnlNorte.add(btnGuardar);
        


        // --- Panel de Visualización (Comparación) ---
        JPanel pnlCentro = new JPanel(new GridLayout(1, 2, 10, 0));
        lblOriginal = new JLabel("Imagen Original", SwingConstants.CENTER);
        lblModificada = new JLabel("Imagen RGB", SwingConstants.CENTER);
        lblGris = new JLabel("Imagen Gris",SwingConstants.CENTER);

        // JScrollPane permite ver imágenes grandes
        pnlCentro.add(new JScrollPane(lblOriginal));
        pnlCentro.add(new JScrollPane(lblModificada));
        pnlCentro.add(new JScrollPane(lblGris));

        // --- Eventos ---


        br.addChangeListener(e -> {
            if (!br.getValueIsAdjusting()) { 
                accionProcesar();
            }
        });

        contr.addChangeListener(e -> {
            if (!contr.getValueIsAdjusting()) {
                accionProcesar();
            }
        });


        pnlBrillo.add(lvlbrillo);
        pnlBrillo.add(br);

        pnlContraste.add(lvlcontraste);
        pnlContraste.add(contr);

        btnAbrir.addActionListener(e -> accionAbrir());
        btnGuardar.addActionListener(e -> accionGuardar());


        pnlContenedor.add(pnlNorte);
        pnlContenedor.add(pnlBrillo);
        pnlContenedor.add(pnlContraste);

        add(pnlContenedor, BorderLayout.NORTH);
        add(pnlCentro, BorderLayout.CENTER);

        setSize(1100, 600);
        setLocationRelativeTo(null);
    }

    private void accionAbrir() {
        JFileChooser selector = new JFileChooser();
        if (selector.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                imgOriginal = ImageIO.read(selector.getSelectedFile());
                lblOriginal.setIcon(new ImageIcon(imgOriginal));
                lblModificada.setIcon(new ImageIcon(imgOriginal)); // Vista previa inicial

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al cargar archivo.");
            }
        }
    }

    private void accionProcesar() {
        if (imgOriginal == null) return;

            int b = br.getValue();
            float c = (float)contr.getValue() / 100.0f;

            
            lvlbrillo.setText("Brillo   : " + b);
            lvlcontraste.setText("contraste: " + c) ;

            // Llamada a la otra clase
            imgModificada = Procesar.Procesar(imgOriginal, b, c,false);
            lblModificada.setIcon(new ImageIcon(imgModificada));

            imgGris = Procesar.Procesar(imgOriginal,b,c,true);
            lblGris.setIcon(new ImageIcon(imgGris));
    }

    private void accionGuardar() {
        if (imgModificada == null) return;
        JFileChooser selector = new JFileChooser();
        JFileChooser selector1 = new JFileChooser();
        if (selector.showSaveDialog(this) == JFileChooser.APPROVE_OPTION && selector.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File output = selector.getSelectedFile();
                File output1 = selector.getSelectedFile();
                // Asegurar formato .jpg
                String path = output.getAbsolutePath();
                if (!path.toLowerCase().endsWith(".jpg")) output = new File(path + ".jpg");
                String path1 = output.getAbsolutePath();
                if (!path.toLowerCase().endsWith(".jpg")) output1 = new File(path + "gris.jpg");
                
                ImageIO.write(imgModificada, "jpg", output);
                ImageIO.write(imgGris, "jpg", output1);
                JOptionPane.showMessageDialog(this, "¡Imagenes guardadas con exito!");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Interfaz().setVisible(true));
    }
}